"""AnonymAIzer - local text anonymization using Rizzo-PII 0.3B.

Run: streamlit run app.py
Requires a locally downloaded Transformers model at MODEL_DIR.
"""
from __future__ import annotations

import os
import re
from collections import Counter, defaultdict
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parent
MODEL_DIR = Path(os.environ.get('ANONYM_AIZER_MODEL', r'C:\AI\models\rizzo-pii-0.3B'))
LABELS = {
    'FULLNAME': 'Nomi e cognomi', 'AGE': 'Età', 'GENDER': 'Genere',
    'DATE': 'Date', 'TIME': 'Orari', 'STREET': 'Strade',
    'BUILDINGNUM': 'Numeri civici', 'ZIPCODE': 'CAP', 'CITY': 'Città',
    'PROVINCE': 'Province', 'EMAIL': 'Email', 'TELEPHONENUM': 'Telefoni',
    'CF': 'Codici fiscali', 'PIVA': 'Partite IVA', 'ID_DOC': 'Documenti identificativi',
    'IBAN': 'IBAN', 'CREDITCARDNUMBER': 'Carte di credito',
    'AMOUNT': 'Importi', 'TARGA': 'Targhe', 'ORG': 'Organizzazioni',
    'DOCID': 'Codici di atti', 'CATASTO': 'Dati catastali',
    'URL': 'URL', 'IPADDR': 'Indirizzi IP',
}
DEFAULT_EXCLUDE = {'AGE', 'GENDER', 'AMOUNT', 'ORG', 'CITY'}
DETECTORS = {
    'EMAIL': re.compile(r'(?<![\w.@])[\w.+%-]+@[\w.-]+\.[A-Za-z]{2,}(?![\w.-])'),
    'URL': re.compile(r'\bhttps?://[^\s<>"\']+', re.I),
    'IPADDR': re.compile(r'(?<!\d)(?:\d{1,3}\.){3}\d{1,3}(?!\d)'),
    'IBAN': re.compile(r'\bIT\d{2}[A-Z]\d{10}[A-Z0-9]{12}\b', re.I),
    'CF': re.compile(r'\b[A-Z]{6}\d{2}[A-EHLMPRST][0-7]\d[A-Z]\d{3}[A-Z]\b', re.I),
}

st.set_page_config(page_title='AnonymAIzer | Anonimizzazione locale',
                   page_icon=str(ROOT / 'assets' / 'favicon.png'), layout='wide')
st.markdown('''<style>
.block-container{padding-top:2rem;max-width:1200px}
[data-testid="stMetric"]{border:1px solid #d9e4ee;border-radius:12px;padding:12px}
</style>''', unsafe_allow_html=True)

@st.cache_resource(show_spinner='Caricamento di Rizzo-PII in corso...')
def load_model(model_path: str):
    from transformers import pipeline
    return pipeline(task='token-classification', model=model_path,
                    tokenizer=model_path, aggregation_strategy='simple',
                    device='cpu', local_files_only=True)


def chunks(text: str, max_words: int = 105, overlap: int = 15):
    """Yield character spans of overlapping word chunks."""
    words = list(re.finditer(r'\S+', text))
    if not words:
        return
    stride = max(1, max_words - overlap)
    for i in range(0, len(words), stride):
        group = words[i:i + max_words]
        if not group:
            break
        left, right = group[0].start(), group[-1].end()
        yield left, text[left:right]
        if i + max_words >= len(words):
            break


def normalize_label(raw: str) -> str:
    label = str(raw).upper().replace('B-', '').replace('I-', '')
    return {'PHONE': 'TELEPHONENUM', 'PERSON': 'FULLNAME',
            'IP': 'IPADDR', 'CREDIT_CARD': 'CREDITCARDNUMBER'}.get(label, label)


def find_entities(text: str, nlp):
    spans = []
    for offset, chunk in chunks(text):
        for e in nlp(chunk):
            label = normalize_label(e.get('entity_group', e.get('entity', 'UNKNOWN')))
            a, b = offset + int(e['start']), offset + int(e['end'])
            if a < b and text[a:b].strip():
                spans.append({'start': a, 'end': b, 'label': label,
                              'score': float(e.get('score', 0)), 'source': 'Modello'})
    for label, regex in DETECTORS.items():
        for m in regex.finditer(text):
            a, b = m.span()
            if label == 'IPADDR' and any(int(x) > 255 for x in m.group().split('.')):
                continue
            spans.append({'start': a, 'end': b, 'label': label,
                          'score': None, 'source': 'Regola'})
    # Exact duplicates occur at overlapping chunk boundaries. Prefer rules for identifiers,
    # then confidence, then longer candidates, and do not replace overlapping spans twice.
    spans.sort(key=lambda x: (0 if x['source'] == 'Regola' else 1,
                              -(x['score'] or 0), -(x['end'] - x['start'])))
    chosen = []
    for s in spans:
        if not any(s['start'] < t['end'] and t['start'] < s['end'] for t in chosen):
            chosen.append(s)
    return sorted(chosen, key=lambda x: x['start'])


def anonymize(text: str, spans: list, enabled: set, reversible: bool):
    counters = defaultdict(int)
    assigned = {}
    mapping = {}
    display_rows = []
    output = []
    cursor = 0
    for s in spans:
        a, b, label = s['start'], s['end'], s['label']
        value = text[a:b]
        masked = label in enabled
        output.append(text[cursor:a])
        if masked:
            key = (label, value.casefold())
            if key not in assigned:
                counters[label] += 1
                assigned[key] = f'[{label}_{counters[label]}]'
            placeholder = assigned[key]
            output.append(placeholder)
            if reversible:
                mapping[placeholder] = value
        else:
            placeholder = ''
            output.append(value)
        display_rows.append({'Categoria': LABELS.get(label, label), 'Valore originale': value,
                             'Segnaposto': placeholder if masked else '—',
                             'Rilevazione': s['source'],
                             'Confidenza': round(s['score'], 3) if s['score'] is not None else '—'})
        cursor = b
    output.append(text[cursor:])
    return ''.join(output), mapping, display_rows, sum(bool(r['Segnaposto'] != '—') for r in display_rows)


def restore(text: str, mapping: dict) -> str:
    # Replace exact tokens, not substrings, to avoid replacing [NAME_1] inside [NAME_10].
    if not mapping:
        return text
    pat = re.compile('|'.join(re.escape(k) for k in sorted(mapping, key=len, reverse=True)))
    return pat.sub(lambda m: mapping[m.group()], text)


if 'output' not in st.session_state:
    st.session_state.output = ''
    st.session_state.mapping = {}
    st.session_state.rows = []
    st.session_state.count = 0
    st.session_state.reversible_result = False

logo = ROOT / 'assets' / 'logo.png'
if logo.exists():
    st.image(str(logo), width=380)
st.caption('Anonimizza testi e proteggi i dati personali con AI eseguita sul tuo computer.')

if not MODEL_DIR.is_dir() or not (MODEL_DIR / 'config.json').is_file():
    st.error(f'Modello non trovato: {MODEL_DIR}. Verifica che la cartella contenga config.json.')
    st.stop()

with st.sidebar:
    st.header('Impostazioni')
    reversible = st.toggle('Consenti ripristino', value=False,
                           help='Il dizionario delle sostituzioni resta nella sessione Streamlit.')
    st.caption('Senza ripristino, non viene creato il dizionario delle sostituzioni. Il testo originale rimane comunque nel campo di input finché non lo cancelli.')
    st.subheader('Categorie da anonimizzare')
    all_tags = list(LABELS)
    selected = st.multiselect('Seleziona le categorie', options=all_tags,
                              default=[t for t in all_tags if t not in DEFAULT_EXCLUDE],
                              format_func=lambda tag: f'{LABELS[tag]} ({tag})')
    st.info('Esecuzione locale sul computer che ospita Streamlit. Se distribuisci l’app su un server, il testo viene inviato a quel server.')
    st.caption('Modello Rizzo-PII 0.3B · Elaborazione CPU')

left, right = st.columns(2, gap='large')
with left:
    st.subheader('Testo originale')
    input_text = st.text_area('Incolla il testo da anonimizzare', height=330,
                              placeholder='Es.: Mario Rossi, email mario.rossi@example.com ...',
                              key='input_text')
    btn_col, reset_col = st.columns([2, 1])
    clicked = btn_col.button('Anonimizza testo', type='primary', use_container_width=True)
    if reset_col.button('Azzera', use_container_width=True):
        for k in ('output', 'mapping', 'rows', 'count', 'input_text'):
            st.session_state.pop(k, None)
        st.rerun()

if clicked:
    if not input_text.strip():
        st.warning('Inserisci un testo da anonimizzare.')
    elif not selected:
        st.warning('Seleziona almeno una categoria da anonimizzare.')
    else:
        try:
            nlp = load_model(str(MODEL_DIR))
            with st.spinner('Analisi delle entità in corso...'):
                spans = find_entities(input_text, nlp)
                result, mapping, rows, count = anonymize(input_text, spans, set(selected), reversible)
            st.session_state.update(output=result, mapping=mapping, rows=rows,
                                    count=count, reversible_result=reversible)
        except Exception as exc:
            st.error(f'Analisi non completata: {type(exc).__name__}: {exc}')

with right:
    st.subheader('Testo anonimizzato')
    st.text_area('Risultato (selezionabile e copiabile)', value=st.session_state.output,
                 height=330)
    st.download_button('Scarica testo anonimizzato (.txt)',
                       data=st.session_state.output.encode('utf-8'),
                       file_name='testo_anonimizzato.txt', mime='text/plain',
                       disabled=not bool(st.session_state.output), use_container_width=True)

if st.session_state.output:
    n_detected = len(st.session_state.rows)
    c1, c2, c3 = st.columns(3)
    c1.metric('Entità rilevate', n_detected)
    c2.metric('Entità anonimizzate', st.session_state.count)
    c3.metric('Categorie rilevate', len({r['Categoria'] for r in st.session_state.rows}))
    with st.expander('Dettaglio entità rilevate', expanded=False):
        st.warning('Questa tabella contiene dati originali: non condividerla insieme al testo anonimizzato.')
        st.dataframe(st.session_state.rows, use_container_width=True, hide_index=True)
    if st.session_state.reversible_result and st.session_state.mapping:
        st.divider()
        st.subheader('Ripristina i dati originali')
        to_restore = st.text_area('Incolla un testo che contiene i segnaposto',
                                  value=st.session_state.output, height=160)
        restored = restore(to_restore, st.session_state.mapping)
        st.text_area('Testo ripristinato', value=restored, height=160)
        st.download_button('Scarica testo ripristinato', restored.encode('utf-8'),
                           file_name='testo_ripristinato.txt', mime='text/plain')
    elif st.session_state.reversible_result:
        st.info('Nessun segnaposto da ripristinare.')
    st.caption('Attenzione: il rilevamento automatico può omettere dati personali o segnalare falsi positivi. Controlla sempre il risultato prima di condividerlo.')
